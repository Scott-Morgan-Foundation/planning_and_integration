import pygame
import pygame.gfxdraw
import math
import json
import time

# Load the data from the JSON file
with open('data2.json') as f:
    data = json.load(f)

# Initialize Pygame
pygame.init()

# Set up some constants
WINDOW_WIDTH = 1024
WINDOW_HEIGHT = 1024
CIRCLE_RADIUS = [100, 200, 300, 400, 500]
CIRCLE_SEGMENTS = [4, 4, 16, 18, 4]
CIRCLE_CENTER = (WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2)
CIRCLE_COLOR = (255, 255, 255)  # White
LINE_COLOR = (255, 0, 0)  # Red
BACKGROUND_COLOR = (0, 0, 0)  # Black
FONT_SIZE = 30
FONT_COLOR = (0, 255, 0)  # Green
LETTER_COLOR = (255, 255, 255)  # White
SEQUENCE_BOX_POSITION = (805, 490)
SEQUENCE_BOX_SIZE = (300, 50)
SEQUENCE_BOX_COLOR = (255, 255, 255)  # White
SEQUENCE_TEXT_POSITION = (810, 505)

# Create the window
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))

# Create a font object
font = pygame.font.Font(None, FONT_SIZE)

# Variables to track dwell time
last_segment = None
dwell_start = None
sequence = ""

# Main game loop
running = True
while running:
    # Fill the background
    screen.fill(BACKGROUND_COLOR)

    # Draw the circles
    for radius in CIRCLE_RADIUS:
        pygame.gfxdraw.aacircle(screen, CIRCLE_CENTER[0], CIRCLE_CENTER[1], radius, CIRCLE_COLOR)

    # Draw the lines
    for i, segments in enumerate(CIRCLE_SEGMENTS):
        for j in range(segments):
            angle = 2 * math.pi * j / segments
            if i == 1:  # Add an offset to the angle for the second circle
                angle += math.pi / 4
            dx1 = CIRCLE_RADIUS[i-1] if i > 0 else 0
            dy1 = CIRCLE_RADIUS[i-1] if i > 0 else 0
            dx2 = CIRCLE_RADIUS[i]
            dy2 = CIRCLE_RADIUS[i]
            pygame.draw.line(screen, LINE_COLOR, (CIRCLE_CENTER[0] + dx1 * math.cos(angle), CIRCLE_CENTER[1] + dy1 * math.sin(angle)), (CIRCLE_CENTER[0] + dx2 * math.cos(angle), CIRCLE_CENTER[1] + dy2 * math.sin(angle)), 1)

    # Get the mouse position
    mouse_x, mouse_y = pygame.mouse.get_pos()

    # Calculate the distance and angle from the center
    dx = mouse_x - CIRCLE_CENTER[0]
    dy = mouse_y - CIRCLE_CENTER[1]
    distance = math.sqrt(dx**2 + dy**2)
    angle = math.atan2(dy, dx)

    # Determine which circle and segment the mouse is in
    circle = None
    segment = None
    for i, radius in enumerate(CIRCLE_RADIUS):
        if distance <= radius:
            circle = i + 1
            segment = int((angle + math.pi) / (2 * math.pi) * CIRCLE_SEGMENTS[i]) + 1
            break

    # Check if the segment has changed
    if (circle, segment) != last_segment:
        last_segment = (circle, segment)
        dwell_start = time.time()
    elif time.time() - dwell_start >= 1:
        
        # If the mouse has dwelled on this segment for 2 seconds, write the character to the sequence
        key = f"{circle}-{segment}"

        if key in data:
            if data[key] in ["UP", "DOWN", "LEFT", "RIGHT", "NUM", "ACCEPT", "REJECT", "NEW", "SMILE", "SAD", "CLAP", "THUMBUP"]:
                continue
            elif data[key] == "RESET":
                sequence = ""
            elif data[key] == "SPACE1":
                sequence += ' '
            elif data[key] == "SPACE2":
                sequence += ' '
            elif data[key] == "ENTER":
                #with open("TEXT.TXT", "a") as file:
                    #file.write(sequence + "\n")
                sequence = ""
            else:
                sequence += data[key]
        dwell_start = time.time()

    # Draw the circle and segment number
    text = font.render(f"circle({circle}), segment({segment})", True, FONT_COLOR)
    screen.blit(text, (10, 10))

# Draw the Letters into the segments

       # Center "Default"
    letter = font.render("#", True, LETTER_COLOR)
    screen.blit(letter, (505, 505))

    # First Ring
    letter = font.render("UP", True, LETTER_COLOR)
    screen.blit(letter, (500, 330))
    letter = font.render("DOWN", True, LETTER_COLOR)
    screen.blit(letter, (495, 660))
    letter = font.render("LEFT", True, LETTER_COLOR)
    screen.blit(letter, (330, 512))
    letter = font.render("RIGHT", True, LETTER_COLOR)
    screen.blit(letter, (640, 512))

    # Second Ring
    letter = font.render("A", True, LETTER_COLOR)
    screen.blit(letter, (455, 265))
    letter = font.render("E", True, LETTER_COLOR)
    screen.blit(letter, (550, 260))
    letter = font.render("T", True, LETTER_COLOR)
    screen.blit(letter, (645, 300))
    letter = font.render("H", True, LETTER_COLOR)
    screen.blit(letter, (705, 370))
    letter = font.render("SPACE", True, LETTER_COLOR)
    screen.blit(letter, (725, 512))
    letter = font.render("D", True, LETTER_COLOR)
    screen.blit(letter, (695, 645))
    letter = font.render("L", True, LETTER_COLOR)
    screen.blit(letter, (636, 715))
    letter = font.render("S", True, LETTER_COLOR)
    screen.blit(letter, (545, 740))
    letter = font.render("R", True, LETTER_COLOR)
    screen.blit(letter, (450, 745))
    letter = font.render("M", True, LETTER_COLOR)
    screen.blit(letter, (355, 710))
    letter = font.render("C", True, LETTER_COLOR)
    screen.blit(letter, (290, 650))
    letter = font.render("N", True, LETTER_COLOR)
    screen.blit(letter, (245, 545))
    letter = font.render("O", True, LETTER_COLOR)
    screen.blit(letter, (250, 450))
    letter = font.render("I", True, LETTER_COLOR)
    screen.blit(letter, (285, 370))
    letter = font.render("U", True, LETTER_COLOR)
    screen.blit(letter, (360, 300))

    # Third Ring
    letter = font.render("F", True, LETTER_COLOR)
    screen.blit(letter, (500, 160))
    letter = font.render("W", True, LETTER_COLOR)
    screen.blit(letter, (625, 175))
    letter = font.render("G", True, LETTER_COLOR)
    screen.blit(letter, (720, 225))
    letter = font.render("Y", True, LETTER_COLOR)
    screen.blit(letter, (800, 330))
    letter = font.render("K", True, LETTER_COLOR)
    screen.blit(letter, (820, 420))
    letter = font.render("Q", True, LETTER_COLOR)
    screen.blit(letter, (820, 590))
    letter = font.render("Z", True, LETTER_COLOR)
    screen.blit(letter, (800, 680))
    letter = font.render("ENTER", True, LETTER_COLOR)
    screen.blit(letter, (700, 775))
    letter = font.render("ACCEPT", True, LETTER_COLOR)
    screen.blit(letter, (590, 835))
    letter = font.render("REJECT", True, LETTER_COLOR)
    screen.blit(letter, (470, 840))
    letter = font.render("NEW", True, LETTER_COLOR)
    screen.blit(letter, (360, 820))
    letter = font.render("J", True, LETTER_COLOR)
    screen.blit(letter, (180, 660))
    letter = font.render("X", True, LETTER_COLOR)
    screen.blit(letter, (145, 540))
    letter = font.render("B", True, LETTER_COLOR)
    screen.blit(letter, (155, 430))
    letter = font.render("P", True, LETTER_COLOR)
    screen.blit(letter, (190, 330))
    letter = font.render("V", True, LETTER_COLOR)
    screen.blit(letter, (260, 235))
    letter = font.render("RESET", True, LETTER_COLOR)
    screen.blit(letter, (245, 770))
    letter = font.render("NUMBER", True, LETTER_COLOR)
    screen.blit(letter, (345, 175))

    # Fourth Ring
    letter = font.render("SMILE", True, LETTER_COLOR)
    screen.blit(letter, (132, 200))
    letter = font.render("SAD", True, LETTER_COLOR)
    screen.blit(letter, (797, 200))
    letter = font.render("CLAP", True, LETTER_COLOR)
    screen.blit(letter, (790, 820))
    letter = font.render("THUMBUP", True, LETTER_COLOR)
    screen.blit(letter, (140, 820))

    # Draw the sequence box
    pygame.draw.rect(screen, SEQUENCE_BOX_COLOR, pygame.Rect(*SEQUENCE_BOX_POSITION, *SEQUENCE_BOX_SIZE))

    # Draw the sequence
    text = font.render(sequence, True, FONT_COLOR)
    screen.blit(text, SEQUENCE_TEXT_POSITION)

    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()
