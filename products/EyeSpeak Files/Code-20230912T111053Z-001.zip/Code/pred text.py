import tkinter as tk
from collections import defaultdict

class TrieNode(object):
    def __init__(self):
        self.children = defaultdict()
        self.terminating = False

class Trie(object):
    def __init__(self):
        self.root = self.get_node()

    def get_node(self):
        return TrieNode()

    def get_index(self, ch):
        return ord(ch) - ord('a')

    def insert(self, word):
        root = self.root
        len1 = len(word)

        for i in range(len1):
            index = self.get_index(word[i])

            if index not in root.children:
                root.children[index] = self.get_node()
            root = root.children.get(index)

        root.terminating = True

def predict_text(t, prefix):
    root = t.root
    for char in prefix:
        index = t.get_index(char)
        if index not in root.children:
            return []
        root = root.children[index]
    return get_words(root, prefix)

def get_words(root, prefix):
    words = []
    if root.terminating:
        words.append(prefix)
    for index, node in root.children.items():
        char = chr(index + ord('a'))
        words.extend(get_words(node, prefix + char))
    return words

def on_key(event):
    def predict():
        if len(event.widget.get()) > 0:
            words = predict_text(t, event.widget.get())
            if words:
                lb.delete(0, tk.END)
                for word in words:
                    lb.insert(tk.END, word)
    root.after_idle(predict)

t = Trie()

# Load words from dictionary.txt
with open('dictionary.txt', 'r') as f:
    words = [line.strip() for line in f]

# Insert words into Trie
for word in words:
    t.insert(word)

root = tk.Tk()
entry = tk.Entry(root)
entry.bind("<Key>", on_key)
entry.pack()
lb = tk.Listbox(root)
lb.pack()
root.mainloop()
